<?php
$id_telegram = "8661190598";
$id_botTele  = "8509631494:AAG7HARrhR3vrzpHzm7hxHaF_sEoz0Dw8Dc";
?>
